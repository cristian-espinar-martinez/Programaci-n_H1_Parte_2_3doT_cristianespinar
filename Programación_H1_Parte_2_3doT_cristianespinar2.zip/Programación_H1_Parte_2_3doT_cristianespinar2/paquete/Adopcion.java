package paquete;


public class Adopcion {
    // Atributos de la clase Adopcion
    private Animal animal; // Animal que ha sido adoptado
    private String nombrePersona; // Nombre de la persona que adopta
    private String dniPersona; // DNI de la persona que adopta
    
    // Constructor para inicializar los atributos
    public Adopcion(Animal animal, String nombrePersona, String dniPersona) {
        this.animal = animal;
        this.nombrePersona = nombrePersona;
        this.dniPersona = dniPersona;
    }
    
    // Método getter para obtener el animal adoptado
    public Animal getAnimal() {
        return animal;
    }
    
    // Método getter para obtener el nombre de la persona
    public String getNombrePersona() {
        return nombrePersona;
    }
    
    // Método getter para obtener el DNI de la persona
    public String getDniPersona() {
        return dniPersona;
    }
    
    // Método para mostrar los datos de la adopción
    public void mostrarDatosAdopcion() {
        System.out.println("DATOS DE ADOPCIÓN:");
        System.out.println("Nombre de la persona: " + nombrePersona);
        System.out.println("DNI de la persona: " + dniPersona);
        System.out.println("Animal adoptado:");
        animal.mostrar(); // Usamos el método mostrar() del animal
    }
}