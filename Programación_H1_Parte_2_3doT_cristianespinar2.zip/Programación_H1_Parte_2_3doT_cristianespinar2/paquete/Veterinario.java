package paquete;

import java.util.ArrayList;
import java.util.Scanner;

public class Veterinario {
    // Lista para almacenar los animales registrados
    ArrayList<Animal> listaAnimales = new ArrayList<>();
    
    // Lista para gestionar las adopciones
    ArrayList<Adopcion> listaAdopciones = new ArrayList<>();
    
    // Objeto Scanner para leer la entrada del usuario
    Scanner scanner = new Scanner(System.in);
    
    // Método para añadir animales a la lista
    public void AñadirAnimales() {
        
        // Se agregan dos animales por defecto para tener datos de prueba
        listaAnimales.add(new Perro("1234", "Tovias", 5, "Dalmata", true, "grande"));
        listaAnimales.add(new Gato("2345", "Buddy", 2, "Golden Retriever", true, true));
        
        System.out.println("Introduce el número para añadir el nuevo animal (1-Perro o 2-Gato): ");
        int tipo = scanner.nextInt(); // Se elige el tipo de animal (Perro o Gato)
        scanner.nextLine(); 
        
        // Pedimos los datos comunes a todos los animales
        System.out.println("Introduce el número del chip: ");
        String numero_chip = scanner.nextLine();
        
        // Verificamos si ya existe un animal con ese chip
        if (existeChip(numero_chip)) {
            System.out.println("Ya existe un animal con ese número de chip.");
            return; // Salimos del método si ya existe
        }
        
        System.out.println("Introduce el nombre: ");
        String nombre = scanner.nextLine();
        
        System.out.println("Introduce la edad: ");
        int edad = scanner.nextInt();
        scanner.nextLine();
        
        System.out.println("Introduce la raza: ");
        String raza = scanner.nextLine();
        
        System.out.println("Introduce si es adoptado o no (true/false): ");
        boolean adoptado = scanner.nextBoolean();
        scanner.nextLine();
        
        // Si el usuario eligió Perro, pedimos el tamaño
        if (tipo == 1) {
            System.out.println("\nIntroduce el tamaño del perro: PEQUEÑO/MEDIANO/GRANDE: ");
            String tamaño = scanner.nextLine();
            // Añadimos el nuevo perro a la lista
            listaAnimales.add(new Perro(numero_chip, nombre, edad, raza, adoptado, tamaño));
        
        // Si el usuario eligió Gato, pedimos el test de leucemia
        } else if (tipo == 2) {
            System.out.println("\nIntroduce el resultado del test de leucemia (true/false): ");
            boolean test_leucemia = scanner.nextBoolean();
            scanner.nextLine();
            // Añadimos el nuevo gato a la lista
            listaAnimales.add(new Gato(numero_chip, nombre, edad, raza, adoptado, test_leucemia));
        }
    }
    
    // Método para buscar un animal por su número de chip
    public void buscarNuevoChip() {
        System.out.println("\nIntroduce el número del chip: ");
        String numero_chip = scanner.nextLine();
        
        boolean encontrado = false; // Variable para saber si lo encontramos o no
        
        // Recorremos la lista y mostramos el animal si lo encontramos
        for (Animal animal : listaAnimales) {
            if (animal.getNumeroChip().equals(numero_chip)) {
                animal.mostrar(); // Mostramos los datos
                encontrado = true;
            }
        }
        
        if (!encontrado) {
            System.out.println("\nNo se ha encontrado ningún animal.");
        }
    }
    
    // Nueva funcionalidad: Realizar adopción
    public void realizarAdopcion() {
        System.out.println("Introduce el número de chip del animal a adoptar: ");
        String numero_chip = scanner.nextLine();
        
        Animal animalEncontrado = null;
        for (Animal animal : listaAnimales) {
            if (animal.getNumeroChip().equals(numero_chip)) {
                animalEncontrado = animal;
                break;
            }
        }
        
        if (animalEncontrado == null) {
            System.out.println("No existe ningún animal con ese número de chip.");
            return;
        }
        
        if (animalEncontrado.adoptado) {
            System.out.println("El animal ya está adoptado.");
            return;
        }
        
        System.out.println("Introduce el nombre de la persona que adopta: ");
        String nombrePersona = scanner.nextLine();
        
        System.out.println("Introduce el DNI de la persona que adopta: ");
        String dniPersona = scanner.nextLine();
        
        // Creamos una nueva adopción y la añadimos a la lista
        Adopcion adopcion = new Adopcion(animalEncontrado, nombrePersona, dniPersona);
        listaAdopciones.add(adopcion);
        
        // Marcamos al animal como adoptado
        animalEncontrado.adoptado = true;
        System.out.println("Adopción realizada con éxito.");
    }
    
    // Nueva funcionalidad: Dar de baja un animal
    public void darDeBajaAnimal() {
        System.out.println("Introduce el número de chip del animal a dar de baja: ");
        String numero_chip = scanner.nextLine();
        
        Animal animalEncontrado = null;
        for (Animal animal : listaAnimales) {
            if (animal.getNumeroChip().equals(numero_chip)) {
                animalEncontrado = animal;
                break;
            }
        }
        
        if (animalEncontrado == null) {
            System.out.println("No existe ningún animal con ese número de chip.");
            return;
        }
        
        // Eliminamos el animal de la lista
        listaAnimales.remove(animalEncontrado);
        
        // Buscamos si hay una adopción asociada y la eliminamos
        Adopcion adopcionEncontrada = null;
        for (Adopcion adopcion : listaAdopciones) {
            if (adopcion.getAnimal().getNumeroChip().equals(numero_chip)) {
                adopcionEncontrada = adopcion;
                break;
            }
        }
        
        if (adopcionEncontrada != null) {
            listaAdopciones.remove(adopcionEncontrada);
        }
        
        System.out.println("El animal ha sido dado de baja correctamente.");
    }
    
    // Nueva funcionalidad: Mostrar estadísticas de gatos
    public void mostrarEstadisticasGatos() {
        int totalGatos = 0;
        int gatosConLeucemia = 0;
        
        for (Animal animal : listaAnimales) {
            if (animal instanceof Gato) {
                totalGatos++;
                Gato gato = (Gato) animal;
                if (gato.test_leucemia) {
                    gatosConLeucemia++;
                }
            }
        }
        
        System.out.println("ESTADÍSTICAS DE GATOS:");
        System.out.println("Número total de gatos: " + totalGatos);
        System.out.println("Número de gatos con test de leucemia positivo: " + gatosConLeucemia);
    }
    
    // Menú principal del programa veterinario
    public void menu() {
        int opcion;
        
        do {
            System.out.println("MENÚ VETERINARIO");
            System.out.println("1. Añadir animal");
            System.out.println("2. Listar animales");
            System.out.println("3. Buscar número de chip");
            System.out.println("4. Realizar adopción");
            System.out.println("5. Dar de baja animal");
            System.out.println("6. Mostrar estadísticas de gatos");
            System.out.println("7. Salir");
            System.out.print("Elige una opción: ");
            
            opcion = scanner.nextInt();
            scanner.nextLine(); 

            switch (opcion) {
                case 1:
                    AñadirAnimales(); // Llamamos al método para añadir un nuevo animal
                    break;
                case 2:
                    for (Animal animal : listaAnimales) {
                        animal.mostrar();
                        System.out.println("--------------------");
                    }
                    break;
                case 3:
                    buscarNuevoChip(); // Buscamos un animal por chip
                    break;
                case 4:
                    realizarAdopcion(); // Realizamos una adopción
                    break;
                case 5:
                    darDeBajaAnimal(); // Damos de baja un animal
                    break;
                case 6:
                    mostrarEstadisticasGatos(); // Mostramos estadísticas de gatos
                    break;
                case 7:
                    System.out.println("Adiós");
                    break;
                default:
                    System.out.println("Opción no válida");
            }
        } while (opcion != 7); // El menú se repite hasta que el usuario elija salir
    }
    
    // Método privado para verificar si ya existe un chip en la lista
    private boolean existeChip(String chip) {
        for (Animal animal : listaAnimales) {
            if (animal.getNumeroChip().equals(chip)) {
                return true;
            }
        }
        return false;
    }
}
